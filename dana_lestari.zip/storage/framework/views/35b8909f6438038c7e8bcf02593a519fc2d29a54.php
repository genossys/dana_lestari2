<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Dana Lestari</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700,900&display=swap" rel="stylesheet">

    <!-- Style -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="<?php echo e(asset('/css/genosstyle.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />
    <link rel="stylesheet" href="<?php echo e(asset ('adminlte/plugins/font-awesome/css/font-awesome.min.css')); ?>">


    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
    <!-- navbar -->
    <div class="container-fluid">


        <nav class="navbar navbar-expand-md navbar-dark fixed-top" style="background-color: #09839B;">
            <a class="navbar-brand" href="/">
                <img src="/images/logoputih.png" height="30px" class="d-inline-block align-top" alt="/images/logoputih.png">
            </a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse " id="navbarNav">
                <ul class="navbar-nav ml-auto " style="margin-right: 20px">
                    <li class="nav-item ">
                        <a class="nav-link mr-3" href="/formKredit">Kredit <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="/formDeposito">Deposito</a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
    <?php echo $__env->yieldContent('content'); ?>

    <!-- produk -->
    <div class="footerLestari">
        <div class="container pt-3 pb-5">
            <div class="row">
                <div class="col-sm-4">
                    <p class="text-font-weight-bold pt-5 text-light" style="font-weight: 700">Kontak Kami</p>
                    <table>
                        <tr>
                            <td valign="top">
                                <i class="fa fa-location-arrow text-light mr-2 " aria-hidden="true"></i></td>
                            <td valign="top">
                                <p class="text-light">Center Point Solo, Jl. Slamet Riyadi No.371, Sondakan, Kec. Laweyan, Kota Surakarta, Jawa Tengah 57147</p>
                            </td>
                        </tr>

                        <tr>
                            <td valign="top">
                                <i class="fa fa-phone text-light mr-2" aria-hidden="true"> </i>
                            </td>
                            <td>
                                <p class="text-light"> (0271) 710033</p>
                            </td>
                        </tr>

                        <tr>
                            <td valign="top">
                                <i class="fa fa-envelope text-light mr-2" aria-hidden="true"></i>
                            </td>
                            <td>
                                <p class="text-light"> danalestari@gmail.com</p>
                            </td>
                        </tr>



                    </table>
                </div>

                <div class="col-sm-4">
                    <p class="text-font-weight-bold pt-5 text-light" style="font-weight: 700">Follow Us</p>
                    <a href="#" class="text-light mr-2" style="font-size: 30px"> <i class="fa fa-facebook" aria-hidden="true"></i></a>
                    <a href="#" class="text-light mr-2" style="font-size: 30px"> <i class="fa fa-twitter" aria-hidden="true"></i></a>
                    <a href="#" class="text-light mr-2" style="font-size: 30px"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                </div>

                <div class="col-sm-4">

                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="https://code.jquery.com/jquery-1.11.0.min.js"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
    <script src="<?php echo e(asset('/js/genosstyle.js')); ?>"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.multiple-items').slick({
                dots: false,
                infinite: true,
                speed: 1500,
                fade: true,
                arrows: false,
                autoplay: true,
                autoplaySpeed: 4000,
                cssEase: 'linear',
                pauseOnHover: false,

            });
        });
    </script>

    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>

    <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH E:\projek\PROGRAM\website\dana_lestari\resources\views/umum/layout.blade.php ENDPATH**/ ?>