@extends('admin.master')
@section('content')
<!-- Content Header (Page header) -->
<section class="content-header">


</section>

<!-- Main content -->
<section class="content">

</section>
<!-- /.content -->

@endsection